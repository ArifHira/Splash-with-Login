package com.example.naseef.myapplication;

public class Constants {

    public static String IS_FIRST_LAUNCH = "IS_FIRST_LAUNCH";
    public static String IS_LOGED_IN = "IS_LOGED_IN";
    public static String EMAIL = "EMAIL";
    public static String PASS = "PASS";
}
