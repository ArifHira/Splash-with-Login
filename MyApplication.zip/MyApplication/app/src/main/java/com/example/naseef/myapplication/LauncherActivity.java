package com.example.naseef.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Switch;

public class LauncherActivity extends AppCompatActivity {

    boolean isFirstLaunch;
    boolean isLogedId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences pref =
                this.getSharedPreferences("my_pref",MODE_PRIVATE);
        isFirstLaunch = pref.getBoolean(Constants.IS_FIRST_LAUNCH,
                true);
        isLogedId = pref.getBoolean(Constants.IS_LOGED_IN,
                false);


        if(isFirstLaunch){
            Intent i = new Intent(LauncherActivity.this,
                    SplashActivity.class);
            startActivity(i);
            pref.edit().putBoolean(Constants.IS_FIRST_LAUNCH, false).apply();
            finish();

        }else if(isLogedId){
            Intent i = new Intent(LauncherActivity.this,
                    HomeActivity.class);
            startActivity(i);
            finish();
        }else{
            Intent i = new Intent(LauncherActivity.this,
                    LoginActivity.class);
            startActivity(i);
            finish();
        }

    }
}
