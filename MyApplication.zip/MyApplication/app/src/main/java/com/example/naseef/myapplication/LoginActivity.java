package com.example.naseef.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    String email;
    String pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText userEt = findViewById(R.id.emailText);
        final EditText passEt = findViewById(R.id.passText);

        final Button logIn = findViewById(R.id.loginBtn);
        Button signup = findViewById(R.id.signupBtn);


        final SharedPreferences pref =
                this.getSharedPreferences("my_pref",MODE_PRIVATE);
        email = pref.getString(Constants.EMAIL,
                null);
        pass = pref.getString(Constants.PASS,
                null);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this,
                        SignUpActivity.class);
                startActivity(i);
            }
        });

        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)){
                    Toast.makeText(LoginActivity.this,
                            "You dont have any account. Please Signup!",
                            Toast.LENGTH_LONG).show();
                }else{
                    String emailText = userEt.getText().toString();
                    String passText = passEt.getText().toString();

                    if(emailText.equalsIgnoreCase(email) &&
                            passText.equals(pass)){
                        Intent i = new Intent(LoginActivity.this,
                                HomeActivity.class);
                        startActivity(i);
                        pref.edit().putBoolean(Constants.IS_LOGED_IN, true).apply();

                        finish();

                    }else{
                        Toast.makeText(LoginActivity.this,
                                "User Name or Password not valid",
                                Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


    }
}
